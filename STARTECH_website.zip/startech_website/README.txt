# STARTECH Website

Files:
- index.html
- style.css
- images/product-1.jpg
- images/product-2.jpg
- images/product-3.jpg

The website has no product prices displayed and all WhatsApp buttons use 0780995758 (Zimbabwe country code +263).

To publish for free, upload the contents of this folder to a static host such as GitHub Pages, Netlify, or Cloudflare Pages.
